from agents.agents_interface import AgentInterface
from game.connect4 import Connect4Game
import numpy as np
import math
import random


# ------------------------------------------------------------------ #
#  Zobrist hashing                                                     #
# ------------------------------------------------------------------ #

# Pre-generated random 64-bit keys for every (row, col, player) triple.
# Using a module-level table means it is computed once at import time
# and shared across all agent instances.
_ROWS, _COLS, _PLAYERS = 6, 7, 3          # player indices 0-2 (0 = empty)
_rng = random.Random(0xDEADBEEF)          # deterministic seed
ZOBRIST: np.ndarray = np.array(
    [[[_rng.getrandbits(64)
       for _ in range(_PLAYERS)]
      for _ in range(_COLS)]
     for _ in range(_ROWS)],
    dtype=np.uint64
)


def _board_hash(board: np.ndarray) -> int:
    """Compute the Zobrist hash of a board in one vectorised pass."""
    h = np.uint64(0)
    rows, cols = board.shape
    for r in range(rows):
        for c in range(cols):
            p = int(board[r, c])
            if p:
                h ^= ZOBRIST[r, c, p]
    return int(h)


def _incremental_hash(h: int, row: int, col: int, player: int) -> int:
    """XOR a single cell into / out of an existing hash (O(1))."""
    return h ^ int(ZOBRIST[row, col, player])


# ------------------------------------------------------------------ #
#  Agent                                                               #
# ------------------------------------------------------------------ #

class MinMaxAgent(AgentInterface):
    """
    Minimax agent for Connect-4 with full alpha-beta pruning.

    Improvements over the original:
      1. Move ordering       — columns are tried centre-first so the pruner
                               sees good moves early and cuts far more branches.
      2. Transposition table — Zobrist-hashed cache stores (score, depth, flag)
                               for every position so identical board states
                               reached via different move sequences are looked
                               up instead of re-evaluated.
      3. Incremental hashing — the hash is updated in O(1) per ply rather than
                               recomputed from scratch after each clone.
      4. Killer-move hint    — a move that caused a beta cutoff at one node is
                               tried first at sibling nodes of the same depth,
                               often triggering another cutoff cheaply.
      5. Double-threat bonus — same heuristic as AlphaBetaAgent so the agent
                               recognises forks without needing extra depth.
      6. Early-exit at root  — an immediate winning move is returned before the
                               full search starts.
    """

    # Transposition-table entry flags
    _EXACT = 0
    _LOWER = 1   # alpha (fail-low)
    _UPPER = 2   # beta  (fail-high)

    def __init__(self, player_id: int, max_depth: int = 5, verbose: bool = False):
        super().__init__(player_id)
        self.max_depth = max_depth
        self.opponent_id = 2 if player_id == 1 else 1
        self.verbose = verbose

        # Transposition table: hash -> (score, depth, flag, best_move)
        self._tt: dict[int, tuple[float, int, int, int | None]] = {}

        # Killer moves: killers[depth] = [move1, move2]
        self._killers: list[list[int | None]] = [[None, None]
                                                  for _ in range(max_depth + 2)]

    # ------------------------------------------------------------------ #
    #  Public API                                                          #
    # ------------------------------------------------------------------ #

    def select_move(self, game: Connect4Game) -> int:
        self._tt.clear()                         # fresh table each move

        valid = self.get_valid_moves(game)
        if not valid:
            return -1

        # FIX 6: Immediate-win shortcut before full search
        for col in valid:
            state = game.clone()
            success, row = state.make_move(col)
            if success and state.check_winner(row, col, self.player_id):
                if self.verbose:
                    print(f"[ROOT] col={col} → IMMEDIATE WIN")
                return col

        best_col, best_score = None, -math.inf
        h = _board_hash(game.board)

        # FIX 1: Order root moves centre-first
        ordered = self._order_moves(valid, game.column_count, game, h, depth=0)

        for col in ordered:
            state = game.clone()
            success, row = state.make_move(col)
            if not success:
                continue

            child_h = _incremental_hash(h, row, col, self.player_id)
            state.switch_player()

            score = self._minimax(
                state, child_h,
                self.max_depth - 1, -math.inf, math.inf,
                is_maximizing=False, depth_label=1
            )

            if self.verbose:
                print(f"[ROOT] col={col}  score={score:>8.2f}"
                      + (" ← best" if score > best_score else ""))

            if score > best_score:
                best_score = score
                best_col = col

        if self.verbose:
            print(f"\n→ chosen col={best_col}  score={best_score:.2f}\n")

        return best_col

    # ------------------------------------------------------------------ #
    #  Minimax with alpha-beta + transposition table                      #
    # ------------------------------------------------------------------ #

    def _minimax(self, state: Connect4Game, h: int,
                 depth: int, alpha: float, beta: float,
                 is_maximizing: bool, depth_label: int = 0) -> float:

        alpha_orig = alpha

        # FIX 2: Transposition-table lookup
        tt_entry = self._tt.get(h)
        if tt_entry is not None:
            tt_score, tt_depth, tt_flag, tt_move = tt_entry
            if tt_depth >= depth:
                if tt_flag == self._EXACT:
                    return tt_score
                elif tt_flag == self._LOWER:
                    alpha = max(alpha, tt_score)
                elif tt_flag == self._UPPER:
                    beta = min(beta, tt_score)
                if alpha >= beta:
                    return tt_score
        else:
            tt_move = None

        # Terminal / leaf checks
        if state.check_draw():
            return 0.0

        valid_moves = self.get_valid_moves(state)
        if not valid_moves:
            return 0.0

        if depth == 0:
            return self._evaluate_board(state.board,
                                        state.row_count,
                                        state.column_count)

        # FIX 1: Order moves with killer-move hint + centre bias
        ordered = self._order_moves(valid_moves, state.column_count,
                                    state, h, depth, tt_move)

        best_move = ordered[0]

        if is_maximizing:
            max_score = -math.inf
            for col in ordered:
                child = state.clone()
                success, row = child.make_move(col)
                if not success:
                    continue

                if child.check_winner(row, col, self.player_id):
                    win_score = 1000 + depth
                    self._store_tt(h, win_score, depth, self._EXACT, col)
                    return win_score

                child_h = _incremental_hash(h, row, col, self.player_id)
                child.switch_player()

                score = self._minimax(child, child_h, depth - 1, alpha, beta,
                                      is_maximizing=False,
                                      depth_label=depth_label + 1)

                if score > max_score:
                    max_score = score
                    best_move = col
                alpha = max(alpha, score)
                if beta <= alpha:
                    self._store_killer(depth, col)   # FIX 4
                    break

            self._store_tt(h, max_score, depth,
                           self._UPPER if max_score <= alpha_orig else
                           (self._LOWER if max_score >= beta else self._EXACT),
                           best_move)
            return max_score

        else:
            min_score = math.inf
            for col in ordered:
                child = state.clone()
                success, row = child.make_move(col)
                if not success:
                    continue

                if child.check_winner(row, col, self.opponent_id):
                    loss_score = -1000 - depth
                    self._store_tt(h, loss_score, depth, self._EXACT, col)
                    return loss_score

                child_h = _incremental_hash(h, row, col, self.opponent_id)
                child.switch_player()

                score = self._minimax(child, child_h, depth - 1, alpha, beta,
                                      is_maximizing=True,
                                      depth_label=depth_label + 1)

                if score < min_score:
                    min_score = score
                    best_move = col
                beta = min(beta, score)
                if beta <= alpha:
                    self._store_killer(depth, col)   # FIX 4
                    break

            self._store_tt(h, min_score, depth,
                           self._UPPER if min_score <= alpha_orig else
                           (self._LOWER if min_score >= beta else self._EXACT),
                           best_move)
            return min_score

    # ------------------------------------------------------------------ #
    #  Move ordering                                                       #
    # ------------------------------------------------------------------ #

    def _order_moves(self, moves: list[int], col_count: int,
                     state: Connect4Game, h: int,
                     depth: int, tt_move: int | None = None) -> list[int]:
        """
        Priority (highest first):
          1. TT best move from a previous search of this position
          2. Killer moves recorded at this depth
          3. Centre-distance — columns nearest the centre tried first
        """
        center = col_count / 2.0
        killers = self._killers[depth] if depth < len(self._killers) else [None, None]

        def priority(col: int) -> tuple:
            is_tt     = col == tt_move
            is_killer = col in killers
            dist      = abs(center - col)
            # Lower tuple = higher priority (we sort ascending)
            return (not is_tt, not is_killer, dist)

        return sorted(moves, key=priority)

    # ------------------------------------------------------------------ #
    #  Transposition table helpers                                         #
    # ------------------------------------------------------------------ #

    def _store_tt(self, h: int, score: float, depth: int,
                  flag: int, best_move: int | None) -> None:
        existing = self._tt.get(h)
        if existing is None or existing[1] <= depth:
            self._tt[h] = (score, depth, flag, best_move)

    def _store_killer(self, depth: int, col: int) -> None:
        """Keep the two most recent killers per depth slot."""
        if depth < len(self._killers):
            slot = self._killers[depth]
            if col != slot[0]:
                slot[1] = slot[0]
                slot[0] = col

    # ------------------------------------------------------------------ #
    #  NumPy-accelerated board evaluation                                 #
    # ------------------------------------------------------------------ #

    def _evaluate_board(self, board: np.ndarray, rows: int, cols: int) -> float:
        score = 0.0

        # Centre-column presence
        center_col = cols // 2
        score += float(np.sum(board[:, center_col] == self.player_id)) * 3

        h_idx = np.arange(4)
        horiz = np.stack([board[:, c:c + (cols - 3)] for c in h_idx], axis=-1)
        vert  = np.stack([board[r:r + (rows - 3), :] for r in h_idx], axis=-1)
        diag  = np.stack([board[r:r + (rows - 3), c:c + (cols - 3)]
                          for r, c in zip(h_idx, h_idx)], axis=-1)
        flip  = np.flipud(board)
        anti  = np.stack([flip[r:r + (rows - 3), c:c + (cols - 3)]
                          for r, c in zip(h_idx, h_idx)], axis=-1)

        for windows in (horiz, vert, diag, anti):
            score += self._score_windows(windows)

        # FIX 5: Double-threat bonus (from AlphaBetaAgent)
        score += self._detect_double_threats(board, rows, cols)

        return score

    def _score_windows(self, windows: np.ndarray) -> float:
        my = np.sum(windows == self.player_id,   axis=-1)
        op = np.sum(windows == self.opponent_id, axis=-1)
        em = np.sum(windows == 0,                axis=-1)

        pure  = op == 0
        block = my == 0

        score = np.zeros_like(my, dtype=np.float32)
        score += np.where(pure  & (my == 3) & (em == 1),  5, 0)
        score += np.where(pure  & (my == 2) & (em == 2),  2, 0)
        score += np.where(block & (op == 3) & (em == 1), -4, 0)
        score += np.where(block & (op == 2) & (em == 2), -1, 0)

        return float(score.sum())

    def _detect_double_threats(self, board: np.ndarray,
                                rows: int, cols: int) -> float:
        my_threats = self._count_threats(board, rows, cols, self.player_id)
        op_threats = self._count_threats(board, rows, cols, self.opponent_id)
        score = 0.0
        if my_threats >= 2:
            score += 10.0
        if op_threats >= 2:
            score -= 10.0
        return score

    def _count_threats(self, board: np.ndarray,
                       rows: int, cols: int, player: int) -> int:
        opponent = 2 if player == 1 else 1
        h_idx = np.arange(4)

        horiz = np.stack([board[:, c:c + (cols - 3)] for c in h_idx], axis=-1)
        vert  = np.stack([board[r:r + (rows - 3), :] for r in h_idx], axis=-1)
        diag  = np.stack([board[r:r + (rows - 3), c:c + (cols - 3)]
                          for r, c in zip(h_idx, h_idx)], axis=-1)
        flip  = np.flipud(board)
        anti  = np.stack([flip[r:r + (rows - 3), c:c + (cols - 3)]
                          for r, c in zip(h_idx, h_idx)], axis=-1)

        total = 0
        for windows in (horiz, vert, diag, anti):
            my = np.sum(windows == player,   axis=-1)
            op = np.sum(windows == opponent, axis=-1)
            em = np.sum(windows == 0,        axis=-1)
            total += int(np.sum((my == 3) & (op == 0) & (em == 1)))

        return total