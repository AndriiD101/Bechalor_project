import math
import random
from agents.agents_interface import AgentInterface
from game.connect4 import Connect4Game


class MCTSNode:
    __slots__ = ('game_state', 'parent', 'move', 'children',
                 'visits', 'wins', 'untried_moves', '_last_player')

    def __init__(self, game_state: Connect4Game, parent=None, move=None):
        self.game_state = game_state
        self.parent = parent
        self.move = move            # Column that led to this node
        self.children: list['MCTSNode'] = []
        self.visits = 0
        self.wins = 0.0
        self.untried_moves = None   # Lazily initialized
        self._last_player = None    # Player who just moved into this node

    def is_fully_expanded(self) -> bool:
        return self.untried_moves is not None and len(self.untried_moves) == 0

    def best_child(self, exploration_weight: float = 1.414) -> 'MCTSNode':
        log_visits = math.log(self.visits)
        return max(
            self.children,
            key=lambda c: (c.wins / c.visits)
                          + exploration_weight * math.sqrt(log_visits / c.visits)
        )

    def most_visited_child(self) -> 'MCTSNode':
        return max(self.children, key=lambda c: c.visits)


class MCTSAgent(AgentInterface):
    """
    Monte-Carlo Tree Search agent for Connect-4.

    Key improvements over the original:
      1. Incremental win detection  — only checks from the last placed piece
         instead of scanning the whole board, reducing _check_terminal from
         O(rows*cols) to O(1) per call.
      2. Tree reuse               — the subtree rooted at the chosen move is
         kept between turns, so future simulations build on prior work.
      3. Guided rollouts          — during simulation, winning / blocking moves
         are played immediately before falling back to random, improving the
         signal-to-noise ratio of each rollout.
      4. Lightweight state copy   — simulation uses a minimal board copy
         instead of a full Connect4Game clone, reducing allocation overhead.
      5. __slots__ on MCTSNode    — lower per-node memory, faster attribute
         access across millions of node operations.
    """

    def __init__(self, player_id: int, num_simulations: int = 500,
                 max_depth: int = 42, exploration_weight: float = 1.414):
        """
        Args:
            player_id:           The ID of this agent's player (1 or 2).
            num_simulations:     MCTS iterations per move decision.
            max_depth:           Maximum plies per simulation rollout
                                 (42 = full Connect-4 game).
            exploration_weight:  UCB1 constant (√2 by default).
        """
        super().__init__(player_id)
        self.opponent_id = 2 if player_id == 1 else 1
        self.num_simulations = num_simulations
        self.max_depth = max_depth
        self.exploration_weight = exploration_weight

        # Persistent root — reused across turns (tree reuse)
        self._root: MCTSNode | None = None

    # ------------------------------------------------------------------ #
    #  Public API                                                          #
    # ------------------------------------------------------------------ #

    def select_move(self, game: Connect4Game) -> int:
        # --- Tree reuse: try to find the current board state in the
        #     subtree left over from the previous move. ---
        root = self._find_or_create_root(game)

        for _ in range(self.num_simulations):
            node = self._select(root)
            node = self._expand(node)
            result = self._simulate(node)
            self._backpropagate(node, result)

        best = root.most_visited_child()
        # Advance the persistent root to the chosen child
        best.parent = None
        self._root = best
        return best.move

    # ------------------------------------------------------------------ #
    #  Tree reuse                                                          #
    # ------------------------------------------------------------------ #

    def _find_or_create_root(self, game: Connect4Game) -> MCTSNode:
        """
        If we have a previous tree, walk it to find the node that matches
        the current board state (i.e. follow the opponent's last move).
        Fall back to a fresh root when the tree is stale or missing.
        """
        if self._root is not None and self._root.children:
            for child in self._root.children:
                if self._boards_equal(child.game_state.board, game.board):
                    child.parent = None
                    return child
            # Opponent played an unexplored move — try grandchildren
            for child in self._root.children:
                for grandchild in child.children:
                    if self._boards_equal(grandchild.game_state.board, game.board):
                        grandchild.parent = None
                        return grandchild

        # No match found — start fresh
        root = MCTSNode(game_state=game.clone())
        root.untried_moves = self._get_valid_moves(game.board,
                                                    game.row_count,
                                                    game.column_count)
        return root

    @staticmethod
    def _boards_equal(a, b) -> bool:
        import numpy as np
        return (a == b).all() if hasattr(a, 'all') else a == b

    # ------------------------------------------------------------------ #
    #  MCTS phases                                                         #
    # ------------------------------------------------------------------ #

    def _select(self, node: MCTSNode) -> MCTSNode:
        """Traverse tree via UCB1 until we reach an expandable node."""
        while True:
            if self._is_terminal_node(node):
                return node
            if not node.is_fully_expanded():
                return node
            node = node.best_child(self.exploration_weight)

    def _expand(self, node: MCTSNode) -> MCTSNode:
        """Add one new child for an untried move."""
        if self._is_terminal_node(node):
            return node

        if node.untried_moves is None:
            node.untried_moves = self._get_valid_moves(
                node.game_state.board,
                node.game_state.row_count,
                node.game_state.column_count
            )

        if not node.untried_moves:
            return node

        move = node.untried_moves.pop()
        new_state = node.game_state.clone()

        success, row = new_state.make_move(move)
        if not success:
            return node

        # FIX 1: Incremental win check — only inspect from (row, move)
        winner = (new_state.current_player
                  if new_state.check_winner(row, move, new_state.current_player)
                  else None)
        new_state.switch_player()

        child = MCTSNode(game_state=new_state, parent=node, move=move)
        child._last_player = new_state.current_player  # player who just moved
        child.untried_moves = ([]
                               if winner is not None or new_state.check_draw()
                               else self._get_valid_moves(new_state.board,
                                                          new_state.row_count,
                                                          new_state.column_count))
        node.children.append(child)
        return child

    def _simulate(self, node: MCTSNode) -> float:
        """
        FIX 3: Guided rollout — prefer immediately winning or blocking moves
        before falling back to a random choice. Returns 1 / 0 / -1.
        """
        state = node.game_state
        rows, cols = state.row_count, state.column_count

        # FIX 4: Work directly on a board copy rather than cloning the full
        # Connect4Game object for every simulation step.
        import numpy as np
        board = state.board.copy()
        current_player = state.current_player
        opponent = self.opponent_id if current_player == self.player_id else self.player_id

        for _ in range(self.max_depth):
            valid = self._get_valid_moves(board, rows, cols)
            if not valid:
                return 0.0  # Draw

            # Prefer: win > block > random
            move = (self._find_winning_move(board, rows, cols, valid, current_player)
                    or self._find_winning_move(board, rows, cols, valid, opponent)
                    or random.choice(valid))

            row = self._drop_piece(board, rows, move, current_player)
            if row == -1:
                break

            # FIX 1: Check win only from the placed piece
            if self._check_winner_fast(board, rows, cols, row, move, current_player):
                return 1.0 if current_player == self.player_id else -1.0

            current_player, opponent = opponent, current_player

        return 0.0

    def _backpropagate(self, node: MCTSNode, result: float) -> None:
        """Propagate the simulation result back up to the root."""
        while node is not None:
            node.visits += 1
            node.wins += result
            node = node.parent

    # ------------------------------------------------------------------ #
    #  Fast board operations (no Connect4Game clone needed)               #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _get_valid_moves(board, rows: int, cols: int) -> list[int]:
        return [c for c in range(cols) if board[rows - 1][c] == 0]

    @staticmethod
    def _drop_piece(board, rows: int, col: int, player: int) -> int:
        """Drop a piece and return the row index, or -1 if the column is full."""
        for row in range(rows):
            if board[row][col] == 0:
                board[row][col] = player
                return row
        return -1

    @staticmethod
    def _check_winner_fast(board, rows: int, cols: int,
                           row: int, col: int, player: int) -> bool:
        """
        FIX 1: O(1) win check relative to board size — only examines the
        four directions through the last-placed piece rather than scanning
        the whole board.
        """
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        for dr, dc in directions:
            count = 1
            for sign in (1, -1):
                r, c = row + sign * dr, col + sign * dc
                while 0 <= r < rows and 0 <= c < cols and board[r][c] == player:
                    count += 1
                    r += sign * dr
                    c += sign * dc
            if count >= 4:
                return True
        return False

    def _find_winning_move(self, board, rows: int, cols: int,
                           valid: list[int], player: int) -> int | None:
        """Return the first move that wins immediately for `player`, or None."""
        import numpy as np
        for col in valid:
            for row in range(rows):
                if board[row][col] == 0:
                    board[row][col] = player
                    won = self._check_winner_fast(board, rows, cols, row, col, player)
                    board[row][col] = 0
                    if won:
                        return col
                    break
        return None

    # ------------------------------------------------------------------ #
    #  Terminal detection (incremental via node metadata)                 #
    # ------------------------------------------------------------------ #

    def _is_terminal_node(self, node: MCTSNode) -> bool:
        """
        A node is terminal if its untried_moves list was set to empty at
        expansion time (meaning a win or draw was detected incrementally).
        Avoids a full board scan on every visited node.
        """
        return node.untried_moves is not None and len(node.untried_moves) == 0 and not node.children