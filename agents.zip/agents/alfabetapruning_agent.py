from agents.agents_interface import AgentInterface
from game.connect4 import Connect4Game
import numpy as np
import math
import random


# ------------------------------------------------------------------ #
#  Module-level window index arrays (shared with RuleBasedAgent)      #
# ------------------------------------------------------------------ #
# Pre-compute the row/col indices of every size-4 window on a 6×7
# board once at import time.  _W_ROWS / _W_COLS have shape (69, 4)
# and let us extract all windows with a single array gather.

def _build_window_indices(rows: int = 6, cols: int = 7):
    coords = []
    for r in range(rows):                          # horizontal
        for c in range(cols - 3):
            coords.append([(r, c + i) for i in range(4)])
    for r in range(rows - 3):                      # vertical
        for c in range(cols):
            coords.append([(r + i, c) for i in range(4)])
    for r in range(rows - 3):                      # diagonal ↘
        for c in range(cols - 3):
            coords.append([(r + i, c + i) for i in range(4)])
    for r in range(3, rows):                       # diagonal ↗
        for c in range(cols - 3):
            coords.append([(r - i, c + i) for i in range(4)])
    arr = np.array(coords, dtype=np.intp)          # (69, 4, 2)
    return arr[:, :, 0], arr[:, :, 1]             # rows, cols  (69, 4)


_W_ROWS, _W_COLS = _build_window_indices()


def _extract_windows(board: np.ndarray) -> np.ndarray:
    """Return all 69 windows as a (69, 4) array — zero Python loops."""
    return board[_W_ROWS, _W_COLS]


# ------------------------------------------------------------------ #
#  Zobrist hashing                                                     #
# ------------------------------------------------------------------ #

_rng = random.Random(0xC04C7_C04C7)
_ZOBRIST = np.array(
    [[[_rng.getrandbits(64) for _ in range(3)]   # player 0/1/2
      for _ in range(7)]
     for _ in range(6)],
    dtype=np.uint64,
)


def _board_hash(board: np.ndarray) -> int:
    h = np.uint64(0)
    for r in range(board.shape[0]):
        for c in range(board.shape[1]):
            p = int(board[r, c])
            if p:
                h ^= _ZOBRIST[r, c, p]
    return int(h)


def _xor_cell(h: int, row: int, col: int, player: int) -> int:
    """Toggle a single cell into/out of a hash in O(1)."""
    return h ^ int(_ZOBRIST[row, col, player])


# ------------------------------------------------------------------ #
#  Agent                                                               #
# ------------------------------------------------------------------ #

class AlphaBetaAgent(AgentInterface):
    """
    Alpha-beta minimax agent for Connect-4.

    Improvements over the original:
      FIX 1 — Transposition table (Zobrist hashing)
               Identical board positions reached via different move
               sequences are looked up instead of re-evaluated.
               Hash is updated in O(1) per ply (incremental XOR).

      FIX 2 — Killer-move heuristic
               Moves that caused a beta cut-off at a given depth are
               tried first at sibling nodes, often triggering another
               cut-off cheaply without a TT hit.

      FIX 3 — Iterative deepening
               The search runs depth 1, 2, … up to max_depth. Each
               shallower result primes the TT with best moves, making
               the full-depth search faster.  Also enables a natural
               time-budget API if needed in the future.

      FIX 4 — Guarded verbose paths
               Path-list concatenation (path + [col]) was happening
               on every node even with verbose=False. All verbose
               bookkeeping is now inside `if self.verbose` guards so
               production runs pay zero overhead for it.

      FIX 5 — Unified window evaluation
               The original reconstructed four sliced window arrays
               (horiz/vert/diag/anti) in both _evaluate_board *and*
               _count_threats (called twice per leaf).  The new code
               extracts all 69 windows once with _extract_windows()
               and scores everything in a single pass.

      FIX 6 — Incremental win check
               check_winner is called only from the last-placed piece
               (four directional scans, O(1)) rather than the full
               board scan the original delegated to Connect4Game.

      FIX 7 — Fast valid-move detection
               Reads the top cell of each column (O(cols)) instead of
               iterating through rows.
    """

    # Transposition-table entry flags
    _EXACT = 0
    _LOWER = 1   # fail-low  (alpha bound)
    _UPPER = 2   # fail-high (beta  bound)

    def __init__(self, player_id: int, max_depth: int = 5,
                 verbose: bool = False):
        super().__init__(player_id)
        self.max_depth = max_depth
        self.opponent_id = 2 if player_id == 1 else 1
        self.verbose = verbose

        # Transposition table: hash -> (score, depth, flag, best_move)
        self._tt: dict[int, tuple[float, int, int, int | None]] = {}

        # Killer moves: _killers[depth] = [move_a, move_b]
        self._killers: list[list[int | None]] = [
            [None, None] for _ in range(max_depth + 2)
        ]

    # ------------------------------------------------------------------ #
    #  Public API                                                          #
    # ------------------------------------------------------------------ #

    def select_move(self, game: Connect4Game) -> int:
        self._tt.clear()
        for slot in self._killers:
            slot[0] = slot[1] = None

        board = game.board
        rows, cols = game.row_count, game.column_count
        valid = self._fast_valid_moves(board, rows, cols)
        if not valid:
            return -1

        if self.verbose:
            print(f"\n{'='*60}")
            print(f"AlphaBeta (player={self.player_id}, depth={self.max_depth})")
            print(f"{'='*60}")

        # Immediate-win shortcut
        for col in valid:
            row = self._drop_row(board, rows, col)
            board[row, col] = self.player_id
            won = _check_winner_fast(board, rows, cols, row, col, self.player_id)
            board[row, col] = 0
            if won:
                if self.verbose:
                    print(f"[ROOT] col={col} → IMMEDIATE WIN, chosen")
                return col

        root_h = _board_hash(board)
        best_col = self._order_moves(valid, cols)[0]
        best_score = -math.inf

        # FIX 3: Iterative deepening — depth 1 … max_depth
        for target_depth in range(1, self.max_depth + 1):
            ordered = self._order_moves(valid, cols, depth=0)
            iter_best_col = best_col
            iter_best_score = -math.inf

            for col in ordered:
                row = self._drop_row(board, rows, col)
                if row == -1:
                    continue

                board[row, col] = self.player_id
                child_h = _xor_cell(root_h, row, col, self.player_id)
                next_player = self.opponent_id

                score = self._alpha_beta(
                    board, rows, cols, child_h,
                    next_player,
                    target_depth - 1, -math.inf, math.inf,
                    depth_label=1,
                    path=[col] if self.verbose else None,
                )
                board[row, col] = 0

                if self.verbose:
                    marker = " ← best" if score > iter_best_score else ""
                    print(f"[d={target_depth}][ROOT] col={col}  "
                          f"score={score:>8.2f}{marker}")

                if score > iter_best_score:
                    iter_best_score = score
                    iter_best_col   = col

            best_col   = iter_best_col
            best_score = iter_best_score

        if self.verbose:
            print(f"\n→ chosen col={best_col}  score={best_score:.2f}\n")

        return best_col

    # ------------------------------------------------------------------ #
    #  Alpha-Beta search                                                   #
    # ------------------------------------------------------------------ #

    def _alpha_beta(
        self,
        board: np.ndarray,
        rows: int,
        cols: int,
        h: int,
        current_player: int,
        depth: int,
        alpha: float,
        beta: float,
        depth_label: int = 0,
        path: list | None = None,
    ) -> float:

        is_maximizing = (current_player == self.player_id)
        alpha_orig = alpha

        # FIX 1: Transposition-table lookup
        tt_entry = self._tt.get(h)
        tt_move: int | None = None
        if tt_entry is not None:
            tt_score, tt_depth, tt_flag, tt_move = tt_entry
            if tt_depth >= depth:
                if tt_flag == self._EXACT:
                    return tt_score
                elif tt_flag == self._LOWER:
                    alpha = max(alpha, tt_score)
                else:
                    beta = min(beta, tt_score)
                if alpha >= beta:
                    return tt_score

        # Terminal / leaf
        valid_moves = self._fast_valid_moves(board, rows, cols)

        if not valid_moves:
            return 0.0

        if depth == 0:
            score = self._evaluate_board(board, rows, cols)
            if self.verbose:
                role = "MAX" if is_maximizing else "MIN"
                indent = "  │" * (self.max_depth - depth_label) + "  ├─"
                print(f"{indent}[{role} d={depth_label}] "
                      f"path={path} → LEAF  score={score:.2f}")
            return score

        # FIX 2+4: Order moves — TT best move → killers → centre bias
        ordered = self._order_moves(valid_moves, cols, depth, tt_move)
        best_move = ordered[0]
        next_player = self.opponent_id if current_player == self.player_id \
                      else self.player_id

        if is_maximizing:
            max_score = -math.inf
            for col in ordered:
                row = self._drop_row(board, rows, col)
                if row == -1:
                    continue

                board[row, col] = current_player

                # FIX 6: Incremental win check
                if _check_winner_fast(board, rows, cols, row, col, current_player):
                    board[row, col] = 0
                    win_score = 1000 + depth
                    if self.verbose:
                        role = "MAX"
                        indent = "  │" * (self.max_depth - depth_label) + "  ├─"
                        print(f"{indent}[{role} d={depth_label}] "
                              f"path={path + [col] if path is not None else [col]}"
                              f" → WIN  score={win_score}")
                    self._store_tt(h, win_score, depth, self._EXACT, col)
                    return win_score

                child_h = _xor_cell(h, row, col, current_player)
                score = self._alpha_beta(
                    board, rows, cols, child_h,
                    next_player,
                    depth - 1, alpha, beta,
                    depth_label + 1,
                    path + [col] if self.verbose and path is not None else None,
                )
                board[row, col] = 0

                if score > max_score:
                    max_score = score
                    best_move = col
                    if self.verbose:
                        role = "MAX"
                        indent = "  │" * (self.max_depth - depth_label) + "  ├─"
                        print(f"{indent}[{role} d={depth_label}] "
                              f"path={path + [col] if path is not None else [col]}"
                              f"  score={score:.2f}  new_best")

                alpha = max(alpha, score)
                if beta <= alpha:
                    self._store_killer(depth, col)   # FIX 2
                    if self.verbose:
                        role = "MAX"
                        indent = "  │" * (self.max_depth - depth_label) + "  ├─"
                        print(f"{indent}[{role} d={depth_label}] "
                              f"BETA CUT-OFF (α={alpha:.2f} β={beta:.2f})")
                    break

        else:
            max_score = math.inf
            for col in ordered:
                row = self._drop_row(board, rows, col)
                if row == -1:
                    continue

                board[row, col] = current_player

                # FIX 6: Incremental win check
                if _check_winner_fast(board, rows, cols, row, col, current_player):
                    board[row, col] = 0
                    loss_score = -1000 - depth
                    if self.verbose:
                        role = "MIN"
                        indent = "  │" * (self.max_depth - depth_label) + "  ├─"
                        print(f"{indent}[{role} d={depth_label}] "
                              f"path={path + [col] if path is not None else [col]}"
                              f" → OPP WIN  score={loss_score}")
                    self._store_tt(h, loss_score, depth, self._EXACT, col)
                    return loss_score

                child_h = _xor_cell(h, row, col, current_player)
                score = self._alpha_beta(
                    board, rows, cols, child_h,
                    next_player,
                    depth - 1, alpha, beta,
                    depth_label + 1,
                    path + [col] if self.verbose and path is not None else None,
                )
                board[row, col] = 0

                if score < max_score:
                    max_score = score
                    best_move = col
                    if self.verbose:
                        role = "MIN"
                        indent = "  │" * (self.max_depth - depth_label) + "  ├─"
                        print(f"{indent}[{role} d={depth_label}] "
                              f"path={path + [col] if path is not None else [col]}"
                              f"  score={score:.2f}  new_best")

                beta = min(beta, score)
                if beta <= alpha:
                    self._store_killer(depth, col)   # FIX 2
                    if self.verbose:
                        role = "MIN"
                        indent = "  │" * (self.max_depth - depth_label) + "  ├─"
                        print(f"{indent}[{role} d={depth_label}] "
                              f"ALPHA CUT-OFF (α={alpha:.2f} β={beta:.2f})")
                    break

        # FIX 1: Store result in transposition table
        if max_score <= alpha_orig:
            flag = self._UPPER
        elif max_score >= beta:
            flag = self._LOWER
        else:
            flag = self._EXACT
        self._store_tt(h, max_score, depth, flag, best_move)

        return max_score

    # ------------------------------------------------------------------ #
    #  Move ordering                                                       #
    # ------------------------------------------------------------------ #

    def _order_moves(self, moves: list[int], col_count: int,
                     depth: int = 0,
                     tt_move: int | None = None) -> list[int]:
        """
        Priority (highest first):
          1. TT best move from a prior search of this exact position
          2. Killer moves recorded at this depth
          3. Centre-distance (original ordering, still valuable)
        """
        center = col_count / 2.0
        killers = self._killers[depth] if depth < len(self._killers) else [None, None]

        def priority(col: int) -> tuple:
            return (col != tt_move,           # False < True → TT move first
                    col not in killers,        # killer moves second
                    abs(center - col))         # then centre bias

        return sorted(moves, key=priority)

    # ------------------------------------------------------------------ #
    #  Transposition table helpers                                         #
    # ------------------------------------------------------------------ #

    def _store_tt(self, h: int, score: float, depth: int,
                  flag: int, best_move: int | None) -> None:
        entry = self._tt.get(h)
        # Only overwrite a shallower or absent entry
        if entry is None or entry[1] <= depth:
            self._tt[h] = (score, depth, flag, best_move)

    def _store_killer(self, depth: int, col: int) -> None:
        """Keep the two most recent killers per depth slot."""
        if depth < len(self._killers):
            slot = self._killers[depth]
            if col != slot[0]:
                slot[1] = slot[0]
                slot[0] = col

    # ------------------------------------------------------------------ #
    #  FIX 5: Unified board evaluation (single window extraction pass)    #
    # ------------------------------------------------------------------ #

    def _evaluate_board(self, board: np.ndarray, rows: int, cols: int) -> float:
        score = 0.0

        # Centre-column presence
        center_col = cols // 2
        score += float(np.sum(board[:, center_col] == self.player_id)) * 3.0

        # FIX 5: Extract all 69 windows once
        windows = _extract_windows(board)          # (69, 4)

        my = (windows == self.player_id).sum(axis=1)
        op = (windows == self.opponent_id).sum(axis=1)
        em = (windows == 0).sum(axis=1)

        pure  = op == 0
        block = my == 0

        # Positional scoring
        sc = np.zeros(len(windows), dtype=np.float32)
        sc += np.where(pure  & (my == 3) & (em == 1),  5.0, 0.0)
        sc += np.where(pure  & (my == 2) & (em == 2),  2.0, 0.0)
        sc += np.where(block & (op == 3) & (em == 1), -4.0, 0.0)
        sc += np.where(block & (op == 2) & (em == 2), -1.0, 0.0)
        score += float(sc.sum())

        # Double-threat bonus (reuses the already-computed my/op/em)
        my_threats = int(np.sum((my == 3) & (op == 0) & (em == 1)))
        op_threats = int(np.sum((my == 0) & (op == 3) & (em == 1)))
        if my_threats >= 2:
            score += 10.0
        if op_threats >= 2:
            score -= 10.0

        return score

    # ------------------------------------------------------------------ #
    #  FIX 7: Fast board helpers                                           #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _fast_valid_moves(board: np.ndarray, rows: int, cols: int) -> list[int]:
        """O(cols) — check only the top cell of each column."""
        return [c for c in range(cols) if board[rows - 1, c] == 0]

    @staticmethod
    def _drop_row(board: np.ndarray, rows: int, col: int) -> int:
        """Return the row a piece would land in, or -1 if full."""
        for row in range(rows):
            if board[row, col] == 0:
                return row
        return -1


# ------------------------------------------------------------------ #
#  FIX 6: Module-level incremental win check                          #
# ------------------------------------------------------------------ #

def _check_winner_fast(board: np.ndarray, rows: int, cols: int,
                        row: int, col: int, player: int) -> bool:
    """
    Check only the four directions through (row, col) — O(1) relative
    to board size instead of a full board scan.
    """
    for dr, dc in ((0, 1), (1, 0), (1, 1), (1, -1)):
        count = 1
        for sign in (1, -1):
            r, c = row + sign * dr, col + sign * dc
            while 0 <= r < rows and 0 <= c < cols and board[r, c] == player:
                count += 1
                r += sign * dr
                c += sign * dc
        if count >= 4:
            return True
    return False